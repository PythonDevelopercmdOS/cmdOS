import keyboard
import requests
import os
import time
from bs4 import BeautifulSoup
import python_weather
import asyncio

txt12 = """
££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££
£                                                                             cmdOS Settings:                                                                                                                            £
££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££
 


                                    









 Switch Theme:
 	dark - press alt+2
 	light - press alt+1
 Turn on/off desktop:
 	 on - press ctrl+shift+1
 	 off - press ctrl+shift+2
 Advanced:
 	 SystemInfo - press ctrl+1
back - press esc

"""
def c1s():
	os.system('cls')
txt ="""
to install app you have to:
open C:/cmdOSPC/cmdOS/programs/
and copy to this folder .bat/.cmd file with link to this app
oap:
Standard programs:
calc
notepad
settings
cmd
"""
text = """
                                                                                   cmdOS Desktop
# to send you help press on ctrl+shift+1
# to open any program press Alt
# to open power menu ctrl+shift+2
"""
def ps():
	
	c1s()
	os.system('echo                                                                                          Time: %time% Date: %date%')
	print('If you want start another program write "ap"')
	chs = input('Choose program: ')
	if chs=='settings':
		settings()
		checkin()
	if chs=='calc':
		os.system('calc')
		checkin()
	if chs=='notepad':
		os.system('notepad')
		checkin()
	if chs=='cmd':
		os.system('start cmd')
		checkin()
	if chs=='ap':
		os.system('start cap.bat')
		checkin()
	if chs=='taskmanager':
		taskmanager()
	else:
		checkin()

def taskmanager():
	os.system('echo                                                                                          Time: %time% Date: %date%')
	c1s()
	print("                                                                                                   cmdOS Task Manager                                           ")
	os.system('tasklist')
	print(' to terminate process press shift+ctrl')
	print(' to exit write press esc')
	print(' to start new process press shift+1')
	while True:
		if keyboard.is_pressed('shift+ctrl'):

			chs = input('Type here name the process to kill: ')
			os.system('taskkill /f /im '+chs)
			time.sleep(1)
			c1s()
			taskmanager()
		if keyboard.is_pressed('esc'):
			checkin()
		if keyboard.is_pressed('shift+1'):
			time.sleep(1)
			chs=input('Type here link to the app: ')
			os.system('start '+chs)
			c1s()
			taskmanager()

def he1p():
	os.system('echo                                                                                          Time: %time% Date: %date%')
	os.system('cls')
	print(txt)
	os.system('pause')
	checkin()
def powermenu():
	os.system('echo                                                                                          Time: %time% Date: %date%')
	c1s()
	print(text2)
	cft = input(' :')
	if cft=='1':
		os.system('shutdown /f /t 0 /s')
	if cft=='2':
		os.system('shutdown /f /t 0 /r')
	if cft=='3':
		os.system('GUIreboot.bat')
	if cft=='4':
		checkin()
def settings():
	c1s()
	os.system('echo                                                                                          Time: %time% Date: %date%')
	print(txt12)
	while True:
		if keyboard.is_pressed('ESC'):
			checkin()
		if keyboard.is_pressed('alt+1'):
			os.system('color 70')
			settings()
		if keyboard.is_pressed('alt+2'):
			os.system('color 07')
			settings()
		if keyboard.is_pressed('ctrl+shift+1'):
			os.system('explorer')
			settings()
		if keyboard.is_pressed('ctrl+shift+2'):
			os.system('taskkill /f /im explorer.exe > nul')
			settings()
		if keyboard.is_pressed('ctrl+1'):
			c1s()
			print('cmdOS version: v.0.1')
			os.system('systeminfo')
			os.system('pause')
			settings()
async def getweather():
    # declare the client. format defaults to metric system (celcius, km/h, etc.)
    client = python_weather.Client(format=python_weather.IMPERIAL)

    # fetch a weather forecast from a city
    weather = await client.find("Tiraspol")

    # returns the current day's forecast temperature (int)
    print(weather.current.temperature)

    # get the weather forecast for a few days
    for forecast in weather.forecasts:
        print(str(forecast.date), forecast.sky_text, forecast.temperature)

    # close the wrapper once done
    await client.close()

def checkin():
	
	os.system('cls')
	os.system('echo                                                                                          Time: %time% Date: %date%')
	print(text)
	loop = asyncio.get_event_loop()
	loop.run_until_complete(getweather())
	time.sleep(0.5)
	while True:
		if keyboard.is_pressed('ctrl+shift+1'):
			he1p()
		if keyboard.is_pressed('alt'):
			ps()
		if keyboard.is_pressed('ctrl+shift+2'):
			powermenu()


print(text)
checkin()



	