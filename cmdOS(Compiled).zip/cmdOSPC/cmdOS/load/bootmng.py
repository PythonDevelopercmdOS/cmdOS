import os
import time
import keyboard
txt = """
££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££
£                                                       CMDos boot manager                                                                                                                                               £
££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££
 













 cmdOS v. 0.1 <
 cmdOS v. 0.1 Recovery
"""
txt1 = """
££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££
£                                                       CMDos boot manager                                                                                                                                               £
££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££££
 













 cmdOS v. 0.1 
 cmdOS v. 0.1 Recovery <
"""

os.system('echo                                                                                          Time: %time% Date: %date%')
print(txt)
def load():
	

	while True:
		if keyboard.is_pressed('Return'):
			os.system('cls')
			os.system('cd C:/cmdOSpc/cmdOS/load')
			os.system('call cmdOSv.0.1.bat')
			exit()
		if keyboard.is_pressed('Down'):
			os.system('cls')
			os.system('echo                                                                                          Time: %time% Date: %date%')
			print(txt1)
			while True:
				if keyboard.is_pressed('Return'):
					os.system('cd C:/cmdOSpc/cmdOS/load')
					os.system('call cmdOSv.0.1.recovery.bat')
					exit()
				if keyboard.is_pressed('Up'):
					os.system('cls')
					os.system('echo                                                                                          Time: %time% Date: %date%')
					print(txt)
					load()
load()
